from setuptools import setup

setup(py_modules=[])
